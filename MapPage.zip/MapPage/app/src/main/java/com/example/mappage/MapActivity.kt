package com.example.mappage

import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MapActivity : AppCompatActivity() {

    private lateinit var buildingSpinner: Spinner
    private lateinit var buildingInfoContainer: LinearLayout
    private lateinit var buildingImage: ImageView
    private lateinit var buildingName: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_map)

        buildingSpinner = findViewById(R.id.buildingSpinner)
        buildingInfoContainer = findViewById(R.id.buildingInfoContainer)
        buildingImage = findViewById(R.id.buildingImage)

        buildingName = findViewById(R.id.buildingName)

        setupBuildingSpinner()
    }

    private fun setupBuildingSpinner() {
        val buildings = arrayOf(
            "Select a building:",
            "CSDL",
            "PTC",
            "CMA",
            "MBA",
            "GYM",
            "Student Plaza (SP)",
            "North Hall (NH)",
            "MBA Hall",
            "Riverside (RS)"
        )

        val adapter = BuildingSpinnerAdapter(this, buildings)
        buildingSpinner.adapter = adapter

        //dropdown part section pards
        buildingSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position > 0) {
                    //User selected a bldg (not placeholder)
                    showBuildingPreview(buildings[position])
                } else {
                    //Hide bldg preview if placeholder is selected
                    buildingInfoContainer.visibility = View.GONE
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                buildingInfoContainer.visibility = View.GONE
            }
        }
    }

    private fun showBuildingPreview(buildingNameText: String) {
        //show the bldg info
        buildingInfoContainer.visibility = View.VISIBLE

        //set bldg name
        buildingName.text = buildingNameText

        // TODO: Load building image from drawable based on building name
        // For now, placeholder image is shown
        // buildingImage.setImageResource(R.drawable.cma_building)

        // TODO: Add building description from database
        // For now, gray line placeholder is shown
    }

    inner class BuildingSpinnerAdapter(
        context: Context,
        private val buildings: Array<String>

    ) : ArrayAdapter<String>(context, R.layout.bldg_item, buildings) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val textView = TextView(context)
            textView.text = buildings[position]

            textView.textSize = 14f
            
            textView.setTextColor(android.graphics.Color.parseColor("#666666"))
            textView.setPadding(48, 36, 48, 36)
            try {textView.typeface = resources.getFont(R.font.poppins_regular)

            } catch (e: Exception) {
            }
            return textView
        }

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
            if (position == 0) {
                val view = layoutInflater.inflate(R.layout.bldg_item, parent, false)
                view.visibility = View.GONE
                view.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0)
                return view
            }

            val view = convertView ?: layoutInflater.inflate(R.layout.bldg_item, parent, false)

            val buildingNameText = view.findViewById<TextView>(R.id.buildingNameText)
            buildingNameText.text = buildings[position]

            return view

        }

        override fun isEnabled(position: Int): Boolean {
            return position != 0
        }
    }
}