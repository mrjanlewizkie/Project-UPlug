package com.example.profilepage

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.InputStream

class ProfileActivity : AppCompatActivity() {

    private lateinit var profilePicture: ImageView
    private lateinit var addPictureIcon: ImageView
    private lateinit var userName: TextView
    private lateinit var userRole: TextView
    private lateinit var accountNumber: TextView
    private lateinit var userEmail: TextView
    private lateinit var userDepartment: TextView
    private lateinit var logoutButton: Button

    private val PICK_IMAGE_REQUEST = 100
    private var selectedImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        profilePicture = findViewById(R.id.profilePicture)
        addPictureIcon = findViewById(R.id.addPictureIcon)
        userName = findViewById(R.id.userName)
        userRole = findViewById(R.id.userRole)
        accountNumber = findViewById(R.id.accountNumber)
        userEmail = findViewById(R.id.userEmail)
        userDepartment = findViewById(R.id.userDepartment)
        logoutButton = findViewById(R.id.logoutButton)

        //to preview profile
        profilePicture.setOnClickListener {
            showImagePreview()
        }

        addPictureIcon.setOnClickListener {
            openImagePicker()
        }

        //logout btn
        logoutButton.setOnClickListener {
            // TODO: Logout logic
            Toast.makeText(this, "Logging out...", Toast.LENGTH_SHORT).show()
        }

        // TODO: Load user data from database
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null) {
            selectedImageUri = data.data
            selectedImageUri?.let { uri ->
                //show crop dialog
                showCropDialog(uri)
            }
        }
    }

    private fun showCropDialog(imageUri: Uri) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_crop_image, null)
        val cropImageView = dialogView.findViewById<ImageView>(R.id.cropImageView)

        //load image into ImageView
        try {
            val inputStream: InputStream? = contentResolver.openInputStream(imageUri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            cropImageView.setImageBitmap(bitmap)
        } catch (e: Exception) {
            Toast.makeText(this, "Error loading image", Toast.LENGTH_SHORT).show()
            return


        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("Adjust Your Photo")
            .setView(dialogView)
            .setPositiveButton("Done") { _, _ ->
                //set the cropped image to profile pic
                try {
                    val inputStream: InputStream? = contentResolver.openInputStream(imageUri)
                    val bitmap = BitmapFactory.decodeStream(inputStream)
                    profilePicture.setImageBitmap(bitmap)

                    // TODO: Upload to database/server
                    Toast.makeText(this, "Profile picture updated!", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Error setting image", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    private fun showImagePreview() {
        //create fullscreen dialog to preview image
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_preview_image, null)
        val previewImageView = dialogView.findViewById<ImageView>(R.id.previewImageView)
        val closeButton = dialogView.findViewById<ImageView>(R.id.closePreviewButton)

        //get current profile picture
        previewImageView.setImageDrawable(profilePicture.drawable)


        val dialog = AlertDialog.Builder(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
            .setView(dialogView)
            .create()

        //close btn
        closeButton.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    // TODO: Load user data from database
    /*
    private fun loadUserData() {
        // Get user data from database
        val user = database.getUserData()

        userName.text = user.name
        userRole.text = user.role
        accountNumber.text = user.accountNumber
        userEmail.text = user.email
        userDepartment.text = user.department

        // Load profile picture
        // Glide.with(this).load(user.profilePicUrl).into(profilePicture)
    }
    */
}