package com.example.newspage

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class NewsActivity : AppCompatActivity() {

    private lateinit var officialNewsButton: Button
    private lateinit var citeNewsButton: Button
    private lateinit var feedContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news)

        // Initialize views
        officialNewsButton = findViewById(R.id.officialNewsButton)
        citeNewsButton = findViewById(R.id.citeNewsButton)
        feedContainer = findViewById(R.id.feedContainer)

        // Official News is already selected by default (in XML)
        // Posts are already showing (from XML placeholders)

        officialNewsButton.setOnClickListener {
            showOfficialNews()
        }

        citeNewsButton.setOnClickListener {
            showCiteNews()
        }
    }



    private fun showOfficialNews() {
        // Change button colors
        officialNewsButton.setBackgroundResource(R.drawable.button_selected)
        citeNewsButton.setBackgroundResource(R.drawable.button_unselected)

        // TODO: When database is ready, clear and reload posts
        // feedContainer.removeAllViews()
        // Load Official News posts from database
        // For now, placeholder posts stay visible
    }

    private fun showCiteNews() {
        // Change button colors
        officialNewsButton.setBackgroundResource(R.drawable.button_unselected)
        citeNewsButton.setBackgroundResource(R.drawable.button_selected)

        // TODO: When database is ready, clear and reload posts
        // feedContainer.removeAllViews()
        // Load Cite News posts from database
        // For now, placeholder posts stay visible
    }
}