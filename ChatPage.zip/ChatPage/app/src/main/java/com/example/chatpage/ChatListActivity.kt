package com.example.chatpage

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class ChatListActivity : AppCompatActivity() {

    private lateinit var chatListContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_list)

        chatListContainer = findViewById(R.id.chatListContainer)

        // TODO: Load chat list from database
        // For now, placeholder chats are showing from XML

        // When a chat item is clicked, open ChatActivity
        setupChatItemClicks()
    }

    private fun setupChatItemClicks() {
        // Get all chat items and set click listeners
        for (i in 0 until chatListContainer.childCount) {
            val chatItem = chatListContainer.getChildAt(i)
            chatItem.setOnClickListener {
                // Open individual chat screen
                val intent = Intent(this, ChatActivity::class.java)
                // TODO: Pass user ID or chat ID to load correct conversation
                // intent.putExtra("userId", userId)
                startActivity(intent)
            }
        }
    }
}