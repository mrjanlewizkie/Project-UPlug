package com.example.chatpage

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ChatActivity : AppCompatActivity() {

    private lateinit var backButton: ImageView
    private lateinit var messagesContainer: LinearLayout
    private lateinit var messageInput: EditText
    private lateinit var sendButton: Button
    private lateinit var attachFileButton: ImageView

    private val FILE_PICKER_REQUEST = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        // Initialize views
        backButton = findViewById(R.id.backButton)
        messagesContainer = findViewById(R.id.messagesContainer)
        messageInput = findViewById(R.id.messageInput)
        sendButton = findViewById(R.id.sendButton)
        attachFileButton = findViewById(R.id.attachFileButton)

        // Back button
        backButton.setOnClickListener {
            finish()
        }

        // Send button
        sendButton.setOnClickListener {
            sendMessage()
        }

        // Attach file button
        attachFileButton.setOnClickListener {
            openFilePicker()
        }

        // TODO: Load messages from database
        // For now, placeholder messages are showing from XML
    }

    private fun sendMessage() {
        val messageText = messageInput.text.toString().trim()

        if (messageText.isNotEmpty()) {
            // Add message to UI
            addSentMessage(messageText)

            // Clear input
            messageInput.text.clear()

            // TODO: Send message to database
            // database.sendMessage(userId, messageText)
        }
    }

    private fun addSentMessage(text: String) {
        val inflater = LayoutInflater.from(this)
        val messageView = inflater.inflate(R.layout.message_item_sent, messagesContainer, false)

        val messageTextView = messageView.findViewById<TextView>(R.id.sentMessageText)
        val timeTextView = messageView.findViewById<TextView>(R.id.sentMessageTime)

        messageTextView.text = text
        timeTextView.text = "Just now"

        messagesContainer.addView(messageView)

        // Scroll to bottom
        findViewById<android.widget.ScrollView>(R.id.messagesScrollView).post {
            findViewById<android.widget.ScrollView>(R.id.messagesScrollView).fullScroll(android.view.View.FOCUS_DOWN)
        }
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "*/*"
        intent.addCategory(Intent.CATEGORY_OPENABLE)

        try {
            startActivityForResult(Intent.createChooser(intent, "Select a File"), FILE_PICKER_REQUEST)
        } catch (e: Exception) {
            Toast.makeText(this, "Please install a File Manager", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == FILE_PICKER_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                handleSelectedFile(uri)
            }
        }
    }

    private fun handleSelectedFile(fileUri: Uri) {
        // Show file selected
        Toast.makeText(this, "File selected: ${fileUri.lastPathSegment}", Toast.LENGTH_SHORT).show()

        // TODO: Upload file to database/server
        // database.uploadFile(fileUri)
    }
}